# 공식 출처와 확인 상태

확인일: 2026-09-19. 이 목록의 제목은 주제를 설명하는 표기이며, 현재 페이지의 HTML 제목이 ‘Duolingo Blog’인 경우도 있다.

## 사용한 자료

| ID | 공식 문서·제작 글 | 발행일 | 이번 확인 수준 | 반영 위치 |
|---|---|---|---|---|
| S1 | [그림체와 형태 언어](https://blog.duolingo.com/shape-language-duolingos-art-style/) | 2020-07-02 | 현재 공식 본문 읽음 | illustration-and-characters.md S1 |
| S2 | [Characters](https://design.duolingo.com/illustration/characters) | 확인하지 않음 | 공식 URL에 대한 검색 수록 본문 읽음. 실제 접속은 디자인 허브로 이동 | illustration-and-characters.md S2 |
| S3 | [Duo](https://design.duolingo.com/illustration/duo) | 확인하지 않음 | 공식 URL에 대한 검색 수록 본문 읽음. 실제 접속은 디자인 허브로 이동 | illustration-and-characters.md S3 |
| S4 | [캐릭터 개발과 제품 속 역할](https://blog.duolingo.com/building-character/) | 2020-11-10 | 현재 공식 본문 읽음 | personality-and-motion.md S4 |
| S5 | [Linda Simensky의 캐릭터·애니메이션 인터뷰](https://blog.duolingo.com/linda-simensky-duocon-interview/) | 2022-08-30 | 현재 공식 본문 읽음 | personality-and-motion.md S5 |
| S6 | [캐릭터의 입 모양과 상태 기반 애니메이션](https://blog.duolingo.com/world-character-visemes/) | 2022-11-10 | 현재 공식 본문 읽음 | personality-and-motion.md S6 |
| S7 | [수학 콘텐츠의 시각 표현과 Rive 적용](https://blog.duolingo.com/developing-math/) | 2024-10-18 | 현재 공식 본문 읽음 | personality-and-motion.md S7 |

발행일은 공식 페이지의 게시 메타데이터로 확인했다. 현재 읽을 수 있다는 사실은 현재 조직의 모든 작업 방식이 해당 시점과 같다는 뜻은 아니다.

## 이전 브랜드 가이드의 접근 한계

2026-09-19 확인에서 `design.duolingo.com`과 위 캐릭터·Duo 주소는 [공식 디자인 허브](https://blog.duolingo.com/hub/design/)로 이동했다. 브라우징 도구와 별도의 HTTP 요청에서 이동을 확인했다. S2·S3의 본문은 검색 결과가 수록한 공식 페이지 내용을 읽었으며, 검색 도구는 약 5개월 전 수집본으로 표시했다. 현재 원문 전체와 삽화를 직접 확인한 것으로 취급하지 않는다.

`https://design.duolingo.com/illustration/shape-language` 경로도 허브로 이동했고 해당 경로의 본문은 확보하지 못했다. 그래서 이 주소의 세부 규칙을 복원했다고 주장하지 않으며, 그림체의 일반 원리는 읽을 수 있는 공식 글 S1을 사용했다. 제삼자가 만든 Duolingo 참고 스킬·디자인 요약은 근거로 채택하지 않았다.

## 다시 확인할 때

- 최신 세부 규칙이 필요하면 원래 공식 주소와 디자인 허브에서 이전·갱신 여부를 확인한다. 검색 본문을 사용할 때는 수집본이라는 상태를 유지한다.
- 그림에만 있는 비율·색상·동작을 텍스트에서 읽은 것처럼 추정하지 않는다. 정확한 시각 기준이 필요한 작업은 접근 가능한 공식 도판을 실제로 확인한다.
- 현재 연결 도구와 API는 S6·S7의 과거 사례와 별도로 해당 도구의 공식 문서에서 확인한다.
- 요약을 수정할 때는 출처별 의미와 확인 상태를 같이 고친다. 서로 다른 문서의 규칙을 한 페이지의 직접 지침처럼 합치지 않는다.

## 스킬에서 추가한 내용

`SKILL.md`의 적용 절차, 입력·종료 조건 연결표, 정적 사용처를 위한 대표 포즈 확인, 산출물 확인 방법은 이 스킬의 작업 절차다. 공식 문서를 인용한 규칙과 구별한다. 로고·서체·기존 캐릭터 원본 파일이나 문서 전문은 포함하지 않는다.
